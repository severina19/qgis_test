# Changelog

## Version 0.1

- First version with multiband image difference
